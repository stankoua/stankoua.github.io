package example

import org.scalatest.funsuite.AnyFunSuite

class StringSpec extends AnyFunSuite {

  test("CHaine vide est  vide") {
    assert("" == "")
  }

  test("Chaine ") {}

}
