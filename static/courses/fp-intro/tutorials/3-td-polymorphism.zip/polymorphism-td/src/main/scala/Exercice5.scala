package fp.course.polymorphism

object Exercice5 {
}
