package fp.course.polymorphism

object Exercice6 {
}
