package fp.course.polymorphism

object Main extends App {
  println("Hello, World!")
}
