package fp.course.polymorphism

object Exercice2 {
}